#' Landing table in MED&BS datacall format
#'
#' @name Landing_tab_example
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords MED&BS datacall
"Landing_tab_example"
