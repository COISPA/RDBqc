## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

library(RDBqc)

## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

library(RDBqc)

## ----input1-------------------------------------------------------------------
head(data_ex)

## ----input2-------------------------------------------------------------------
head(data_exampleCL)

## ----RCG_check_LFD------------------------------------------------------------
RCG_check_LFD(data_ex,MS="ITA",GSA="GSA99", SP="Mullus barbatus",min_len=6,max_len=250)[[1]]

## ----RCG_check_LFD2,fig.height=6,fig.width=9----------------------------------
RCG_check_LFD(data_ex,MS="ITA",GSA="GSA99", SP="Mullus barbatus",min_len=6,max_len=250)[[2]]

## ----RCG_check_LFD_comm_cat---------------------------------------------------
RCG_check_LFD_comm_cat(data_ex,MS="ITA",GSA="GSA99", SP="Mullus barbatus")[[1]]

## ----RCG_check_LFD_comm_cat2,fig.height=6,fig.width=9-------------------------
RCG_check_LFD_comm_cat(data_ex,MS="ITA",GSA="GSA99", SP="Mullus barbatus")[[2]]

## ----RCG_check_AL-------------------------------------------------------------
results <- RCG_check_AL(data_ex,MS="ITA",GSA="GSA99",SP="Mullus barbatus",min_age=0,max_age=5)[[1]]
head(results)

## ----RCG_check_AL2------------------------------------------------------------
RCG_check_AL(data_ex,MS="ITA",GSA="GSA99",SP="Mullus barbatus",min_age=0,max_age=5)[[2]]

## ----RCG_check_AL3,fig.height=6,fig.width=9-----------------------------------
RCG_check_AL(data_ex,MS="ITA",GSA="GSA99",SP="Mullus barbatus",min_age=0,max_age=5)[[3]]

## ----RCG_check_lw2,fig.height=6,fig.width=9-----------------------------------
RCG_check_lw(data_ex,MS="ITA",GSA="GSA99", SP="Mullus barbatus",Min=0,Max=200)[[2]]

## ----RCG_check_lw1------------------------------------------------------------
RCG_check_lw(data_ex,MS="ITA",GSA="GSA99", SP="Mullus barbatus",Min=0,Max=200)[[1]]

## ----RCG_check_mat, results='hide', message=FALSE, warning=FALSE,fig.height=6,fig.width=9----
RCG_check_mat(data_ex,MS="ITA",GSA="GSA99",SP="Mullus barbatus")

## ----RCG_check_mat_ogive,fig.height=6,fig.width=9-----------------------------
RCG_check_mat_ogive(data_ex,MS="ITA",GSA="GSA99",SP="Mullus barbatus", sex="F",immature_stages=c("0","1","2a"))

## ----RCG_summarize_ind_meas---------------------------------------------------
results <- RCG_summarize_ind_meas(data=data_ex,MS="ITA",GSA="GSA99",SP="Mullus barbatus")
head(results)

## ----RCG_summarize_trips------------------------------------------------------
results <- RCG_summarize_trips(data_ex,MS="ITA",GSA="GSA99",SP="Mullus barbatus")
head(results)

## ----RCG_check_loc,fig.height=8,fig.width=10----------------------------------
RCG_check_loc(data_ex)

## ----RCG_check_CL1------------------------------------------------------------
RCG_check_CL(data_exampleCL,MS="COUNTRY1",GSA="GSA99",SP="Parapenaeus longirostris")[[1]]

## ----RCG_check_CL2------------------------------------------------------------
RCG_check_CL(data_exampleCL,MS="COUNTRY1",GSA="GSA99",SP="Parapenaeus longirostris")[[2]]

## ----RCG_check_CL3------------------------------------------------------------
RCG_check_CL(data_exampleCL,MS="COUNTRY1",GSA="GSA99",SP="Parapenaeus longirostris")[[3]]

## ----RCG_check_CL4------------------------------------------------------------
RCG_check_CL(data_exampleCL,MS="COUNTRY1",GSA="GSA99",SP="Parapenaeus longirostris")[[4]]

## ----RCG_check_CL5------------------------------------------------------------
RCG_check_CL(data_exampleCL,MS="COUNTRY1",GSA="GSA99",SP="Parapenaeus longirostris")[[5]]

## ----RCG_check_CL6------------------------------------------------------------
RCG_check_CL(data_exampleCL,MS="COUNTRY1",GSA="GSA99",SP="Parapenaeus longirostris")[[6]]

## ----RCG_check_CL7,fig.height=6,fig.width=9-----------------------------------
RCG_check_CL(data_exampleCL,MS="COUNTRY1",GSA="GSA99",SP="Parapenaeus longirostris")[[7]]

## ----Catch_tab_example--------------------------------------------------------
head(Catch_tab_example)

## ----Landing_tab_example------------------------------------------------------
head(Landing_tab_example)

## ----Discard_tab_example------------------------------------------------------
head(Discard_tab_example)

## ----MEDBS_check_duplicates_catches-------------------------------------------
catch_with_diplicate <- rbind(Catch_tab_example,Catch_tab_example[1,])
MEDBS_check_duplicates(data=catch_with_diplicate,type="c",MS="ITA",GSA="GSA 9",SP="DPS",verbose=TRUE)

## ----MEDBS_Catch_coverage1----------------------------------------------------
results <- suppressMessages(MEDBS_Catch_coverage(Catch_tab_example,"DPS","ITA","GSA 9"))
head(results[[1]])

## ----MEDBS_Catch_coverage2----------------------------------------------------
head(results[[2]])

## ----MEDBS_Catch_coverage3,fig.height=6,fig.width=9---------------------------
results[[3]]

## ----MEDBS_Catch_coverage4,fig.height=6,fig.width=9---------------------------
results[[4]]

## -----------------------------------------------------------------------------
MEDBS_SOP(data=Catch_tab_example,SP="DPS",MS="ITA",GSA="GSA 9",threshold = 5)

## -----------------------------------------------------------------------------
MEDBS_SOP(data=Catch_tab_example,SP="DPS",MS="ITA",GSA="GSA 9",threshold = 2)

## ----MEDBS_check_duplicates_landings------------------------------------------
Landing_tab_example <- rbind(Landing_tab_example,Landing_tab_example[1,])
MEDBS_check_duplicates(data=Landing_tab_example,type="l",MS="ITA",GSA="GSA 9",SP="DPS",verbose=TRUE)

## ----MEDBS_check_duplicates_discards------------------------------------------
Discard_tab_example <- rbind(Discard_tab_example,Discard_tab_example[1,])
MEDBS_check_duplicates(data=Discard_tab_example,type="d",SP="DPS",MS="ITA",GSA="GSA 9",verbose=TRUE)

