#' Ports coordinates according to codification CIRCABC
#' @name circabc
#' @docType data
#' @author CIRCABC
#' @keywords CIRCABC Harbour
"circabc"

utils::globalVariables(c("circabc"))
