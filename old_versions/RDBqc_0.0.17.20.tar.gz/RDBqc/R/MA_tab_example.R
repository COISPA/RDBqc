#' MA table in MED&BS datacall format
#'
#' @name MA_tab_example
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords MED&BS datacall
"MA_tab_example"
