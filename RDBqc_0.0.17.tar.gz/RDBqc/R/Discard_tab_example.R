#' Discard table in MED&BS datacall format
#'
#' @name Discard_tab_example
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords MED&BS datacall
"Discard_tab_example"
