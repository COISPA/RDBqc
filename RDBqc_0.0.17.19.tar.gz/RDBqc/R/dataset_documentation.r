#' task_ii2 in GFCM DCRF datacall format
#'
#' @name task_ii2
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords GFCM DCRF datacall
"task_ii2"


#' task_iii in GFCM DCRF datacall format
#'
#' @name task_iii
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords GFCM DCRF datacall
"task_iii"


#' task_vii2 in GFCM DCRF datacall format
#'
#' @name task_vii2
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords GFCM DCRF datacall
"task_vii2"


#' task_vii31 in GFCM DCRF datacall format
#'
#' @name task_vii2
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords GFCM DCRF datacall
"task_vii2"


#' task_vii32 in GFCM DCRF datacall format
#'
#' @name task_vii32
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords GFCM DCRF datacall
"task_vii32"

#' fdi_a_catch in FDI DGMAREMED&BS datacall format
#'
#' @name fdi_a_catch
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords FDI DGMAREMED&BS datacall
"fdi_a_catch"

#' fdi_g_effort in FDI DGMAREMED&BS datacall format
#'
#' @name fdi_g_effort
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords FDI DGMAREMED&BS datacall
"fdi_g_effort"

#' fdi_h_spatial_land in FDI DGMAREMED&BS datacall format
#'
#' @name fdi_h_spatial_land
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords FDI DGMAREMED&BS datacall
"fdi_h_spatial_land"

#' fdi_h_spatial_landings in FDI DGMAREMED&BS datacall format
#'
#' @name fdi_h_spatial_landings
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords FDI DGMAREMED&BS datacall
"fdi_h_spatial_landings"

#' fdi_i_spatial_effort in FDI DGMAREMED&BS datacall format
#'
#' @name fdi_i_spatial_effort
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords FDI DGMAREMED&BS datacall
"fdi_i_spatial_effort"

#' fdi_j_capacity in FDI DGMAREMED&BS datacall format
#'
#' @name fdi_j_capacity
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords FDI DGMAREMED&BS datacall
"fdi_j_capacity"

#' combination_taskII2 in GFCM datacall format
#'
#' @name combination_taskII2
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords GFCM datacall
"combination_taskII2"

#' catfau_check in GFCM datacall format
#'
#' @name catfau_check
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords GFCM datacall
"catfau_check"

#' sex_mat in GFCM datacall format
#'
#' @name sex_mat
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords GFCM datacall
"sex_mat"

#' minmaxLtaskVII2 in GFCM datacall format
#'
#' @name minmaxLtaskVII2
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords GFCM datacall
"minmaxLtaskVII2"

#' task_vii31 in GFCM datacall format
#'
#' @name task_vii31
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords GFCM datacall
"task_vii31"

#' minmaxLtaskVII31 in GFCM datacall format
#'
#' @name minmaxLtaskVII31
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords GFCM datacall
"minmaxLtaskVII31"

#' GSAlist table
#'
#' @name GSAlist
#' @docType data
#' @author Walter Zupa \email{zupa@fondazionecoispa.org}
#' @keywords GSAlist
"GSAlist"

#' SSPP table
#'
#' @name SSPP
#' @docType data
#' @author Walter Zupa \email{zupa@fondazionecoispa.org}
#' @keywords SSPP
"SSPP"

#' AER catch table
#'
#' @name aer_catch
#' @docType data
#' @author Vasiliki Sgardeli \email{vsgard@hcmr.gr}
#' @keywords aer_catch
"aer_catch"

#' MEDBSSP table
#'
#' @name MEDBSSP
#' @docType data
#' @author Alessandro Mannini \email{alessandro.mannini@irbim.cnr.it}
#' @keywords MEDBSSP
"MEDBSSP"
