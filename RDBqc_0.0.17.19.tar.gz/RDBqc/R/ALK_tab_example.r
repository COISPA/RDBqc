#' ALK table in MED&BS datacall format
#'
#' @name ALK_tab_example
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords MED&BS datacall
"ALK_tab_example"
