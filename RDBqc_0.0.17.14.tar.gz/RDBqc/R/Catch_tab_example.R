#' Catch table in MED&BS datacall format
#'
#' @name Catch_tab_example
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords MED&BS datacall
"Catch_tab_example"
