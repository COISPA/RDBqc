# RDBqc 0.1.3 (06/03/2026)
* Fixes for RDBFIS III
  * check_RD_FDI_H and check_RD_FDI_I modified for inconsistencies in detecting disaggregated records
# RDBqc 0.1.2 (25/02/2026)
* Fixes for RDBFIS III
  * Performance and reporting updates for MEDBS QC workflows, including an embedded versus standalone plotting strategy in the MEDBS RMarkdown report to reduce computational time.
  * Updated plotting dependencies and imports to support the revised visual outputs in `MEDBS_Catch_CAA` (added `lattice` and `HH`).
  * `MEDBS_GP_check` updated by adding an optional parameter `all_plots = FALSE` to avoid generating plots that are not printed in the MEDBS RMarkdown report.
  * Functions generating MEDBS time series plots were updated to correctly handle datasets with a single available year (single-year cases are plotted as points rather than time series areas).
  * `MEDBS_Catch_coverage` updated to correctly handle datasets with a single available year (not only full time series).
  * `MEDBS_ALK_MLAA` updated to (i) remove spurious coercion warnings during `LENGTHCLASS` parsing by recoding `LENGTHCLASS100_PLUS` to `LENGTHCLASS100` before numeric conversion, and (ii) change the mean length-at-age visualisation to overlay yearly series in a single panel (small points and coloured lines by year) instead of using faceting, ensuring that at least one point is visible also in single-year cases.
  * `MEDBS_ALK_NB` updated to include `LENGTHCLASS` in the grouping for total-number estimation, improving internal consistency of the aggregation.
  * MEDBS RMarkdown report updated to reduce computational time by running the most computationally demanding functions under more conservative settings and by disabling non-essential plots and tables only when `RDBqc` is executed embedded within RDBFIS.

# RBDqc 0.1.1 (08/01/2026)
 * Fixes for RDBFIS III
   * The function MEDBS_length_ind() was updated to improve computational performance when repeatedly called across multiple species and GSAs (e.g., within RMarkdown reports), without altering its overall logic, structure, or returned outputs. Estimated improvement ≈ 10 × faster.
   * MEDBS_ks() was revised to improve performance and robustness when executed repeatedly in automated reporting workflows. The internal implementation was updated to reduce redundant computations and data reshaping within each call
   * MEDBS_Catch_LW was revised correcting the names of columns in the selection of mean lengh at age data.
   * MEDBS_report_HTML was updated to deal with null datasets in ALK (when calling MEDBS_ALK_MLA and MEDBS_ALK_NB functions) and Catch (when calling MEDBS_Catch_LW and MEDBS_Catch_CAA functions)

# RBDqc 0.1.0 (26/06/2025)
 * Fixes for RDBFIS III
   * MEDBS_GP_check addedd new plots of boxplot of Linf, k and t0 parameters of VBGF
   * MEDBS_LW_check addedd new plots of boxplot of both a and b parameters of growth parameters
   * MEDBS_ks has been refactored for speed and memory efficiency. The function no longer calls clus.lf() with 100 bootstrap resamples; instead, a lightweight helper (calc_KS_ID()) computes the Kolmogorov–Smirnov statistic analytically from vectorised length-frequency tables. Length-class columns are converted to numeric in a single multithreaded data.table pass, cumulative curves are built with a grouped cumsum(), and all data-frame merges have been replaced by in-place data-table joins. The public interface and output (KS decisions, cumulative plots) are unchanged, but runtime drops from ~5 s to ~0.16 s (≈ 30 × faster) and peak memory from ~645 MB to ~25 MB.
   * New function: MEDBS_ALK_NB to verify the consistency between the total number of hard structures read and the sum of the structures by age
   * New function: MEDBS_Catch_CAA to facilitate the check of catch at age by year in the Catch table through a multi-panel barplots of numbers-at-age, including landing and discard. 
   * New function: MEDBS_Catch_LW to visually check of mean length and mean weight reported in the Catch table.
   * New function: MEDBS_ALK_MLAA to visually check the mean length at age based on the ALK table. 
   
# RBDqc 0.0.17.25 (19/03/2025)
 * included the read.coded.file function to be used in Rmd templates to automatically select the encoding for opening the tables 
# RBDqc 0.0.17.25
 * FDI_fishdays_cov.r updated to check the class of field 'totfishdays' in tables G and I and transform it to numeric if needed.
 * FDI_disc_coverage.r updated to transforms NAs to NK and return a warning.
# RBDqc 0.0.17.24
 * check_presence_taskII2 function checked and merging issues corrected
# RBDqc 0.0.17.23
 * MEDBS_LW_check unit of measure included in the curve ID in the legend of the plots
# RBDqc 0.0.17.22
 * MEDBS_LFD improved NA and -1 value management
 * MEDBS_MA_check and MEDBS_ML_check points were included in the plots
# RBDqc 0.0.17.21
 * RCG_check_LFD modified to work with datasets with only one record
# RBDqc 0.0.17.20
 * improvement of MEDBS_length_ind and to RCG_check_mat_ogive functions
# RBDqc 0.0.17.19
 * included warning messages in FDI_disc_coverage function in case NA values are detected in the discards field.
 * improved management of unexpected class in numeric fields of landing and discard tables on MED&BS data call functions
 * improvement of vessel length code transformation from character to numeric in FDI_vessel_lenth function
# RBDqc 0.0.17.17
 * correction bug on MEDBS_LFD for discards
# RBDqc 0.0.17.16
 * inclusion of 'GFCM_check_headers' function allowing to convert the GFCM headers from RDBFIS to GFCM format
# RBDqc 0.0.17.15
 * addressing new table format in FDI data call (new field "metier_7" and new colnames for rectangle_lat and rectangle_lon fields)
# RBDqc 0.0.17.14
 * Bug correction in check_age_MEDBS_AR
# RDBqc 0.0.17.12
 * Improvement of outputs of check_ldf_TaskVII.2 function
 * Improvement of outputs of RCG_check_loc
 * Improvement of outputs of RCG_summarize_ind_meas
 * RCG_check_mat_ogive
# RDBqc 0.0.17.10
 * Improvement of outputs of MEDBS_check_missing_years function
 * Improvement of outputs of FDI_AER_land_landvalue function
# RDBqc 0.0.17.09
 * Improvement of outputs of MEDBS_ks function 
 * Improvement of plots in MEDBS_LW_check function
# RDBqc 0.0.17.08
 * 5% threshold value introduced in the FDI_AER_land_landvalue function output
 * MEDBS cross-checks modified to allow GSA filter with and without space (e.g. "GSA18","GSA 18")
# RDBqc 0.0.17.07
 * updated version of FDI_AER_land_landvalue function
# RDBqc 0.0.17.06
 * Improving output saving in the cross-data call checks
# RDBqc 0.0.17.05
 * Inclusion of a new function to detect the presence of disaggregated data: MEDBS_check_disaggregated
 * Inclusion of a new function to detect the presence of missing years in data: MEDBS_check_missing_years

# RDBqc 0.0.17.04
 * Improved checks for missing data in landing for MEDBS_length_ind function
 * modification of table output in MEDBS_LFD function

# RDBqc 0.0.17.03
 * Modification of SOP table output
 * inclusion of check on "sex_ratio" header in SA and SL tables

# RDBqc 0.0.17.02
 * improving results of MEDBS functions (SOP, Discard_coverage, plot_discard_ts, plot_disc_vol) 
 * expansion of MEDBS_check_duplicates function to all MED&BS tables of biological parameters (GP, ALK, MA, ML, SRA, SRL)

# RDBqc 0.0.17
 * improving results of MEDBS functions (ALK, LFD, yr_missing_length) 
 * expansion of MEDBS_check_duplicates function to all MED&BS tables of biological parameters (GP, ALK, MA, ML, SRA, SRL)

# RDBqc 0.0.16
 * update compatibility with R version 4.3

# RDBqc v0.0.15
  * included new functions for cross-checks between data calls' tables (developed in the frame of QualiTrain project)
  
# RDBqc v0.0.11
  * included new FDI functions
  
# RDBqc v0.0.10
  * update of MEDBS functions
  * new functions to check SOP and ALK
  * implemented the treatment of NA values for VESSEL_LENGTH, GEAR, FISHERY and MESH_SIZE_RANGE in MEDBS functions 
  * Included new FDI functions
  
# RDBqc v0.0.9
  * toupper in colnames of MEDBS checks 
  
# RDBqc v0.0.8
  * Vignette included in the library
  * some bugs solved

# RDBqc v0.0.7
  * README completed with examples
  * some bugs solved

# RDBqc v0.0.6
  * Lots of scripts' modifications

# RDBqc v0.0.5
  * Lots of scripts' modifications

# RDBqc v0.0.4
  * MEDBS checks implemented

# RDBqc v0.0.3
  * GFCM checks implemented 

# RDBqc v0.0.2
  * FDI checks implemented 

# RDBqc v0.0.1
  * MED&BS - RCG functions implemented
