#' task_ii2 table in GFCM DCRF datacall format
#'
#' @name task_ii2
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords GFCM DCRF datacall
"task_ii2"
