#' SL table in MED&BS datacall format
#'
#' @name SL_tab_example
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords MED&BS datacall
"SL_tab_example"
