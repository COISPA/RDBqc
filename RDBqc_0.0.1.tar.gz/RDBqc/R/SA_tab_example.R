#' SA table in MED&BS datacall format
#'
#' @name SA_tab_example
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords MED&BS datacall
"SA_tab_example"
