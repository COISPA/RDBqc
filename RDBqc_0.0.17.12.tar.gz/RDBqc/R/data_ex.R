#' RCG CS example
#'
#' @name data_ex
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords RCG CS samplingData
"data_ex"
