RDBqc v0.0.2
==============
- FDI checks implemented 

RDBqc v0.0.1
==============
- base functions implemented
