#' GP table in MED&BS datacall format
#'
#' @name GP_tab_example
#' @docType data
#' @author Isabella Bitetto \email{bitetto@coispa.it}
#' @keywords MED&BS datacall
"GP_tab_example"
