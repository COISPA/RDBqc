#' Discards data table as example
#'
#' @name discards
#' @docType data
#' @keywords data
"discards"
