#' Landing data table as example
#'
#' @name landing
#' @docType data
#' @keywords data
"landing"
