RDBqc v0.0.3
==============
- GFCM checks implemented 

RDBqc v0.0.2
==============
- FDI checks implemented 

RDBqc v0.0.1
==============
- MED&BS - RCG functions implemented
