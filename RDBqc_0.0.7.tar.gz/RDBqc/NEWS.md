- RDBqc v0.0.7
  - README completed with examples
  - some bugs solved

- RDBqc v0.0.6
  - Lots of scripts' modifications

- RDBqc v0.0.5
  - Lots of scripts' modifications

- RDBqc v0.0.4
  - MEDBS checks implemented

- RDBqc v0.0.3
  - GFCM checks implemented 

- RDBqc v0.0.2
  - FDI checks implemented 

- RDBqc v0.0.1
  - MED&BS - RCG functions implemented
